# calculate_interest
calculate simple interest and compound interest using client application and print messeges using logger using java
in this program frame is used to inputs from user
logger is used to give errors or messages
this promgram is used to calculate yearly interest
